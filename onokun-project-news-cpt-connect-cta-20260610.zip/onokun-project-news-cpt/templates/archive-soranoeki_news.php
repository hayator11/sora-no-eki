<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="primary" class="site-main">
    <section class="soranoeki-news-archive">
        <header class="page-header">
            <h1 class="page-title">空の駅からのお知らせ</h1>
            <p>空の駅の営業情報、イベント、里親さんへのお知らせをお届けします。</p>
        </header>

        <?php if (have_posts()) : ?>
            <div class="soranoeki-news-list">
                <?php while (have_posts()) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('soranoeki-news-item'); ?>>
                        <?php if (has_post_thumbnail()) : ?>
                            <a href="<?php the_permalink(); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>">
                                <?php the_post_thumbnail('medium_large'); ?>
                            </a>
                        <?php endif; ?>

                        <header class="entry-header">
                            <p class="entry-date"><?php echo esc_html(get_the_date()); ?></p>
                            <h2 class="entry-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                        </header>

                        <div class="entry-summary">
                            <?php the_excerpt(); ?>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <?php the_posts_pagination(); ?>
        <?php else : ?>
            <p>現在、公開中のお知らせはありません。</p>
        <?php endif; ?>
    </section>
</main>

<?php
get_footer();
