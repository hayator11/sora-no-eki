<?php
/**
 * Plugin Name: Onokun Project News CPT
 * Description: おのくん関連プロジェクト用のカスタム投稿タイプを追加します。現在は「空の駅NEWS」を定義します。
 * Version: 1.1.0
 * Author: Onokun Project
 * Text Domain: onokun-project-news-cpt
 */

if (!defined('ABSPATH')) {
    exit;
}

define('ONOKUN_PROJECT_NEWS_CPT_VERSION', '1.1.0');
define('ONOKUN_PROJECT_NEWS_CPT_DIR', plugin_dir_path(__FILE__));

add_action('init', 'onokun_project_news_register_soranoeki_news');
add_filter('template_include', 'onokun_project_news_template_include');
add_action('wp_enqueue_scripts', 'onokun_project_news_enqueue_assets');
add_filter('the_content', 'onokun_project_news_append_connect_cta');
add_action('admin_notices', 'onokun_project_news_admin_notices');

register_activation_hook(__FILE__, 'onokun_project_news_activate');
register_deactivation_hook(__FILE__, 'onokun_project_news_deactivate');

function onokun_project_news_register_soranoeki_news()
{
    if (post_type_exists('soranoeki_news')) {
        return;
    }

    $labels = array(
        'name'                  => '空の駅NEWS',
        'singular_name'         => '空の駅NEWS',
        'menu_name'             => '空の駅NEWS',
        'name_admin_bar'        => '空の駅NEWS',
        'add_new'               => '新規追加',
        'add_new_item'          => '空の駅NEWSを追加',
        'new_item'              => '新しい空の駅NEWS',
        'edit_item'             => '空の駅NEWSを編集',
        'view_item'             => '空の駅NEWSを表示',
        'all_items'             => '空の駅NEWS一覧',
        'search_items'          => '空の駅NEWSを検索',
        'not_found'             => '空の駅NEWSはありません',
        'not_found_in_trash'    => 'ゴミ箱に空の駅NEWSはありません',
        'archives'              => '空の駅NEWS',
        'attributes'            => '空の駅NEWSの属性',
        'insert_into_item'      => '空の駅NEWSに挿入',
        'uploaded_to_this_item' => 'この空の駅NEWSへのアップロード',
        'filter_items_list'     => '空の駅NEWS一覧を絞り込む',
        'items_list_navigation' => '空の駅NEWS一覧ナビゲーション',
        'items_list'            => '空の駅NEWS一覧',
    );

    register_post_type(
        'soranoeki_news',
        array(
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'show_in_rest'       => true,
            'rest_base'          => 'soranoeki_news',
            'has_archive'        => 'soranoeki/news',
            'rewrite'            => array(
                'slug'       => 'soranoeki/news',
                'with_front' => false,
            ),
            'supports'           => array(
                'title',
                'editor',
                'thumbnail',
                'excerpt',
                'custom-fields',
                'revisions',
            ),
            'menu_icon'          => 'dashicons-megaphone',
            'menu_position'      => 22,
            'capability_type'    => 'post',
            'map_meta_cap'       => true,
            'query_var'          => true,
        )
    );
}

function onokun_project_news_template_include($template)
{
    if (is_post_type_archive('soranoeki_news')) {
        $theme_template = locate_template('archive-soranoeki_news.php');
        if ($theme_template) {
            return $theme_template;
        }

        $plugin_template = ONOKUN_PROJECT_NEWS_CPT_DIR . 'templates/archive-soranoeki_news.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }

    if (is_singular('soranoeki_news')) {
        $theme_template = locate_template('single-soranoeki_news.php');
        if ($theme_template) {
            return $theme_template;
        }

        $plugin_template = ONOKUN_PROJECT_NEWS_CPT_DIR . 'templates/single-soranoeki_news.php';
        if (file_exists($plugin_template)) {
            return $plugin_template;
        }
    }

    return $template;
}

function onokun_project_news_enqueue_assets()
{
    if (!is_singular('soranoeki_news')) {
        return;
    }

    wp_register_style('onokun-project-news-cpt', false, array(), ONOKUN_PROJECT_NEWS_CPT_VERSION);
    wp_enqueue_style('onokun-project-news-cpt');
    wp_add_inline_style(
        'onokun-project-news-cpt',
        '.onokun-news-connect{margin:40px 0 28px;padding:24px;border:1px solid #e8dccb;border-radius:8px;background:#fffaf1}.onokun-news-connect h2{margin:0 0 10px;font-size:clamp(22px,3vw,30px)}.onokun-news-connect h3{margin:20px 0 10px;font-size:18px}.onokun-news-connect p{margin:0 0 14px}.onokun-news-connect__buttons{display:flex;flex-wrap:wrap;gap:10px}.onokun-news-connect__buttons a{display:inline-flex;align-items:center;min-height:34px;padding:7px 12px;border:1px solid #d34f2f;border-radius:999px;background:#fff;color:#963a27;font-size:13px;font-weight:700;text-decoration:none}.onokun-news-connect__buttons a:hover{background:#d34f2f;color:#fff}'
    );
}

function onokun_project_news_render_connect_cta()
{
    $hatena_url = 'https://b.hatena.ne.jp/entry/s/' . preg_replace('#^https?://#', '', get_permalink());
    ?>
    <section class="onokun-news-connect" aria-labelledby="onokun-news-connect-title">
        <h2 id="onokun-news-connect-title">おのくんとつながる</h2>
        <p>記事を読んで気になった方は、オープンチャットやSNSから気軽につながってください。</p>

        <h3>オープンチャット</h3>
        <div class="onokun-news-connect__buttons">
            <a href="https://line.me/ti/g2/l_r88aCvFnX6D6JqjLQBnIi1zhEatqT-tk2c4Q?utm_source=invitation&utm_medium=link_copy&utm_campaign=default" target="_blank" rel="noopener noreferrer">おのくん親バカサロン</a>
            <a href="https://line.me/ti/g2/b26E1JogLaVG_XwQwgsCMfC7HWrD8VW5EkyOUQ?utm_source=invitation&utm_medium=link_copy&utm_campaign=default" target="_blank" rel="noopener noreferrer">孤独な挑戦者を、減らしたい</a>
            <a href="https://line.me/ti/g2/HjKxe2B4sga1oHRX9l85iqkclEilF6T-ODbBOA?utm_source=invitation&utm_medium=link_copy&utm_campaign=default" target="_blank" rel="noopener noreferrer">レボリストLab</a>
        </div>

        <h3>SNSをフォローする</h3>
        <div class="onokun-news-connect__buttons">
            <a href="https://x.com/onokun1" target="_blank" rel="noopener noreferrer">X おのくん公式</a>
            <a href="https://x.com/Bosai_Bosai_" target="_blank" rel="noopener noreferrer">X 防災×帽祭</a>
            <a href="https://x.com/REVOLIST11" target="_blank" rel="noopener noreferrer">X レボリストLab</a>
            <a href="https://x.com/Hayator" target="_blank" rel="noopener noreferrer">X @hayator</a>
            <a href="https://www.instagram.com/mendokushe.onokun" target="_blank" rel="noopener noreferrer">Instagram おのくん公式</a>
            <a href="https://www.facebook.com/onokunpages" target="_blank" rel="noopener noreferrer">Facebook おのくん公式</a>
            <a href="<?php echo esc_url($hatena_url); ?>" target="_blank" rel="noopener noreferrer">はてなブックマークに登録</a>
        </div>
    </section>
    <?php
}

function onokun_project_news_append_connect_cta($content)
{
    if (!is_singular('soranoeki_news') || !in_the_loop() || !is_main_query()) {
        return $content;
    }

    ob_start();
    onokun_project_news_render_connect_cta();
    return $content . ob_get_clean();
}

function onokun_project_news_activate()
{
    onokun_project_news_register_soranoeki_news();
    onokun_project_news_store_conflict_notice();
    flush_rewrite_rules();
}

function onokun_project_news_deactivate()
{
    flush_rewrite_rules();
}

function onokun_project_news_store_conflict_notice()
{
    $messages = array();

    if (get_page_by_path('soranoeki/news')) {
        $messages[] = '固定ページ「/soranoeki/news/」が存在する可能性があります。空の駅NEWS一覧URLと競合しないか確認してください。';
    }

    $category = get_term_by('slug', 'news', 'category');
    if ($category && !is_wp_error($category)) {
        $messages[] = 'カテゴリー「news」が存在します。通常投稿のカテゴリーURLと競合しないか確認してください。';
    }

    if (!empty($messages)) {
        set_transient('onokun_project_news_cpt_conflicts', $messages, 60);
    }
}

function onokun_project_news_admin_notices()
{
    $messages = get_transient('onokun_project_news_cpt_conflicts');
    if (empty($messages) || !current_user_can('manage_options')) {
        return;
    }

    delete_transient('onokun_project_news_cpt_conflicts');
    echo '<div class="notice notice-warning is-dismissible"><p><strong>Onokun Project News CPT:</strong></p><ul>';
    foreach ($messages as $message) {
        echo '<li>' . esc_html($message) . '</li>';
    }
    echo '</ul></div>';
}
