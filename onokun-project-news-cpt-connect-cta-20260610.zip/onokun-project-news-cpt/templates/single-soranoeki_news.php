<?php
if (!defined('ABSPATH')) {
    exit;
}

get_header();
?>

<main id="primary" class="site-main">
    <?php while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class('soranoeki-news-single'); ?>>
            <header class="entry-header">
                <p class="entry-date"><?php echo esc_html(get_the_date()); ?></p>
                <h1 class="entry-title"><?php the_title(); ?></h1>
            </header>

            <?php if (has_post_thumbnail()) : ?>
                <div class="post-thumbnail">
                    <?php the_post_thumbnail('large'); ?>
                </div>
            <?php endif; ?>

            <div class="entry-content">
                <?php the_content(); ?>
            </div>
        </article>

        <nav class="post-navigation" aria-label="空の駅NEWS">
            <p><a href="<?php echo esc_url(get_post_type_archive_link('soranoeki_news')); ?>">空の駅NEWS一覧へ戻る</a></p>
        </nav>
    <?php endwhile; ?>
</main>

<?php
get_footer();
