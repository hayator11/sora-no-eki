# Onokun Project News CPT

WordPress に「空の駅NEWS」専用のカスタム投稿タイプを追加するプラグインです。

## 追加される投稿タイプ

- 投稿タイプ名: `soranoeki_news`
- 管理画面表示名: `空の駅NEWS`
- 一覧URL: `/soranoeki/news/`
- 個別URL: `/soranoeki/news/記事スラッグ/`
- REST API: `/wp-json/wp/v2/soranoeki_news?per_page=3&_embed`

## 使い方

1. `onokun-project-news-cpt` フォルダを WordPress の `wp-content/plugins/` にアップロードします。
2. WordPress 管理画面の「プラグイン」から `Onokun Project News CPT` を有効化します。
3. 管理画面に表示される「空の駅NEWS」から記事を投稿します。

## 注意

- `functions.php` へは直書きしていません。
- 通常投稿とは分離されます。
- `bosai_news` には触れていません。
- 既存テーマ側に `archive-soranoeki_news.php` または `single-soranoeki_news.php` がある場合は、テーマ側テンプレートを優先します。

## 1.1.0

- 空の駅NEWS記事の本文下に、オープンチャット・SNSフォロー・はてなブックマークのCTAを追加します。
- CTAは `soranoeki_news` の個別記事だけに表示されます。
